/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projekti.tietokanta;

/**
 *
 * @author Tomi
 */
public class Optimointilogiikka {

    //
    
    /**
     * Optimointilogiikka ottaa käyttöliittymältä vastaan listan tarvittavista kangista ja hakee tietokannasta setin,
    jolla hukkaa syntyy kaikkein vähiten. Haku täytyy tehdä kanki kerrallaan ja jos hukkaa syntyy yli metrin, kanki menee "väliaikasvarastoon"
    listalle, joka on mukana seuraavissa hauissa. Listalle jääneet palikat talletetaan tietokantaan. Toteutetaan vasta kolmannessa iteraatiossa.
     */
    
    

     
    
}
